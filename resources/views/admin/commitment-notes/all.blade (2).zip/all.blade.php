@extends('layouts.sneat')

@section('title', 'All Commitment Notes')

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="card shadow-none border">
        <div class="card-header border-bottom bg-white py-3 d-flex justify-content-between align-items-center no-print">
            <div class="d-flex align-items-center">
                <div class="avatar flex-shrink-0 me-3">
                    <span class="avatar-initial rounded bg-label-primary"><i class="bx bx-list-ul"></i></span>
                </div>
                <div>
                    <h5 class="card-title mb-0 text-dark fw-bold">Commitment Notes</h5>
                    <small class="text-muted">Overview of all customer commitments and order stages</small>
                </div>
            </div>
            <div class="d-flex gap-2">
                <div class="btn-group">
                    <button type="button" class="btn btn-outline-secondary btn-sm dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bx bx-export me-1"></i> Export
                    </button>
                    <ul class="dropdown-menu shadow">
                        <li><a class="dropdown-item" href="javascript:void(0);" id="exportExcel"><i class="bx bx-spreadsheet me-2 text-success"></i>Excel</a></li>
                        <li><a class="dropdown-item" href="javascript:void(0);" id="exportPdf"><i class="bx bxs-file-pdf me-2 text-danger"></i>PDF</a></li>
                        <li><a class="dropdown-item" href="javascript:void(0);" id="exportWord"><i class="bx bx-file me-2 text-info"></i>Word</a></li>
                    </ul>
                </div>
                <button class="btn btn-label-secondary btn-sm" onclick="window.print()">
                    <i class="bx bx-printer me-1"></i>Print
                </button>
                <a href="{{ route('admin.commitment-notes.create') }}" class="btn btn-primary btn-sm shadow-sm">
                    <i class="bx bx-plus me-1"></i>Add New
                </a>
            </div>
        </div>

        <div class="card-body p-0">
            <div class="table-responsive text-nowrap p-3">
                <table id="commitmentTable" class="table table-hover border-top admin-excel-table">
                    <thead>
                        <tr>
                            <th width="40" class="text-center">#</th>
                            <th>Date</th>
                            <th>Customer Name</th>
                            <th>Phone</th>
                            <th>Products</th>
                            <th class="text-center">Qty</th>
                            <th class="text-end">Amount (₹)</th>
                            <th>Delivery</th>
                            <th>Type</th>
                            <th>Stage</th>
                            <th>Supplier</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($notes as $index => $note)
                        <tr>
                            <td class="text-center text-muted small">{{ $index + 1 }}</td>
                            <td><span class="text-body fw-medium">{{ $note->created_at->format('d/M/y') }}</span></td>
                            <td>
                                <span class="fw-bold text-dark">{{ $note->cus_name ?? 'N/A' }}</span>
                            </td>
                            <td class="text-muted">{{ $note->customer_phone }}</td>
                            <td title="{{ $note->product_name }}">
                                <small class="text-truncate d-inline-block" style="max-width: 180px;">{{ $note->product_name }}</small>
                            </td>
                            <td class="text-center">{{ $note->order_qty }}</td>
                            <td class="text-end fw-bold text-dark">₹{{ number_format($note->mrp, 2) }}</td>
                            <td><small class="fw-medium text-secondary">{{ $note->delivery_date ? $note->delivery_date->format('d/m/Y') : '-' }}</small></td>
                            <td>
                                <span class="badge bg-label-{{ $note->delivery_type == 'home' ? 'info' : 'secondary' }} rounded-pill">
                                    {{ ucfirst($note->delivery_type) }}
                                </span>
                            </td>
                            <td>
                                @php
                                    $stages = \App\Models\CommitmentNote::getWorkflowStages();
                                    $stage = $stages[$note->workflow_stage] ?? null;
                                    $color = $stage['color'] ?? 'secondary';
                                @endphp
                                <span class="badge bg-{{ $color }} bg-glow py-1 px-2">
                                    {{ $stage['name'] ?? $note->workflow_stage }}
                                </span>
                            </td>
                            <td><span class="text-muted small">{{ Str::limit($note->supplier, 15) }}</span></td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
    /* Table Enhancements */
    .admin-excel-table { font-size: 0.85rem; }
    .admin-excel-table thead th { 
        background-color: #f8f9fa !important;
        text-transform: uppercase; 
        font-size: 0.72rem;
        letter-spacing: 0.8px; 
        font-weight: 700 !important;
        color: #566a7f !important;
        border-bottom: 1px solid #d9dee3 !important;
        padding: 12px 15px !important;
    }
    .admin-excel-table td { 
        vertical-align: middle !important; 
        border-bottom: 1px solid #f0f2f4; 
        padding: 10px 15px !important;
    }
    .admin-excel-table tbody tr:hover { background-color: #fcfcfd !important; }

    /* UI Components */
    .bg-glow { box-shadow: 0 2px 6px 0 rgba(0,0,0,0.12); }
    .btn-label-secondary { background: #ebeef0; color: #8592a3; border-color: transparent; }
    .btn-label-secondary:hover { background: #8592a3 !important; color: #fff !important; }
    
    /* DataTable Customization */
    .goback-wrapper { margin-right: 15px; }
    .dataTables_filter input { 
        border-radius: 6px; 
        border: 1px solid #d9dee3; 
        padding: 0.4rem 0.8rem;
        margin-left: 10px;
    }
    .dataTables_length select { border-radius: 6px; border: 1px solid #d9dee3; padding: 0.3rem; }

    /* Print Specific Styles */
    @media print {
        .layout-navbar, .layout-menu, .content-footer, .no-print, 
        .dataTables_filter, .dataTables_length, .dataTables_paginate, 
        .dataTables_info, .goback-wrapper, .btn-group, .btn { 
            display: none !important; 
        }
        .container-p-y { padding: 0 !important; }
        .card { border: none !important; box-shadow: none !important; }
        table { width: 100% !important; border: 1px solid #ddd !important; font-size: 10px; }
        .admin-excel-table thead th { background-color: #eee !important; color: #000 !important; }
    }
</style>
@endsection

@push('scripts')
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.3.6/js/buttons.html5.min.js"></script>

<script>
    $(document).ready(function() {
        // Initialize DataTable
        var table = $('#commitmentTable').DataTable({
            "paging": true,
            "pageLength": 10,
            "ordering": true,
            "info": true,
            "order": [[1, "desc"]],
            "dom": "<'row px-3 py-3'<'col-sm-12 col-md-4'l><'col-sm-12 col-md-8 d-flex align-items-center justify-content-end'<'goback-wrapper'>f>>" +
                   "<'row'<'col-sm-12'tr>>" +
                   "<'row p-3'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
            "language": { 
                search: "", 
                searchPlaceholder: "Search everything...",
                lengthMenu: "_MENU_ per page"
            },
            "buttons": [
                { 
                    extend: 'excelHtml5', 
                    title: 'Commitment_Notes_Export', 
                    exportOptions: { columns: ':visible' } 
                },
                { 
                    extend: 'pdfHtml5', 
                    title: 'Commitment Notes Report',
                    orientation: 'landscape', 
                    pageSize: 'A4',
                    exportOptions: { columns: ':visible' } 
                }
            ]
        });

        // Insert "Go Back" button next to search
        $("div.goback-wrapper").html('<a href="{{ url()->previous() }}" class="btn btn-outline-secondary btn-sm"><i class="bx bx-chevron-left me-1"></i>Go Back</a>');

        // Export Triggering
        $('#exportExcel').on('click', function() { table.button(0).trigger(); });
        $('#exportPdf').on('click', function() { table.button(1).trigger(); });
        
        // Custom Word Export
        $('#exportWord').on('click', function() {
            var content = document.getElementById('commitmentTable').outerHTML;
            var header = "<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'><head><meta charset='utf-8'><style>table { border-collapse: collapse; width: 100%; } th, td { border: 1px solid black; padding: 8px; text-align: left; font-family: Arial; font-size: 10pt; }</style></head><body><h2 style='text-align:center'>Commitment Notes Report</h2>";
            var footer = "</body></html>";
            var sourceHTML = header + content + footer;
            
            var source = 'data:application/vnd.ms-word;charset=utf-8,' + encodeURIComponent(sourceHTML);
            var fileDownload = document.createElement("a");
            document.body.appendChild(fileDownload);
            fileDownload.href = source;
            fileDownload.download = 'Commitment_Notes.doc';
            fileDownload.click();
            document.body.removeChild(fileDownload);
        });
    });
</script>
@endpush