<!DOCTYPE html>
<html
lang="en"
class="light-style layout-menu-fixed"
dir="ltr"
data-theme="theme-default"
data-assets-path="{{ asset('sneat/assets/') }}"
data-template="vertical-menu-template-free"
>
<head>
    <meta charset="utf-8" />
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />
    <title>@yield('title', config('app.name'))</title>
    <meta name="description" content="" />
    
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="{{ asset('sneat/assets/img/favicon/favicon.ico') }}" />
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
        href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
        rel="stylesheet"
    />
    
    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="{{ asset('sneat/assets/vendor/fonts/boxicons.css') }}" />
    
    <!-- Core CSS -->
    <link rel="stylesheet" href="{{ asset('sneat/assets/vendor/css/core.css') }}" class="template-customizer-core-css" />
    <link rel="stylesheet" href="{{ asset('sneat/assets/vendor/css/theme-default.css') }}" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="{{ asset('sneat/assets/css/demo.css') }}" />
    
    <!-- Vendors CSS -->
    <link rel="stylesheet" href="{{ asset('sneat/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css') }}" />
    @stack('styles')
    
    <!-- Helpers -->
    <script src="{{ asset('sneat/assets/vendor/js/helpers.js') }}"></script>
    
    <!-- Template config files -->
    <script src="{{ asset('sneat/assets/js/config.js') }}"></script>
    
    <!-- Add custom styles for sidebar toggle -->
    <style>
        /* Sidebar toggle styles */
        .layout-menu-toggle-btn {
            cursor: pointer;
            font-size: 1.5rem;
            color: #697a8d;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 50%;
        }
        
        .layout-menu-toggle-btn:hover {
            background-color: rgba(105, 108, 255, 0.1);
            color: #696cff;
        }
        
        /* Collapsed sidebar styles */
        body.menu-collapsed .layout-menu {
            transform: translateX(-100%);
            transition: transform 0.3s ease;
        }
        
        body.menu-collapsed .layout-page {
            margin-left: 0 !important;
            width: 100% !important;
            transition: margin-left 0.3s ease, width 0.3s ease;
        }
        
        /* Ensure smooth transitions */
        .layout-menu,
        .layout-page {
            transition: transform 0.3s ease, margin-left 0.3s ease, width 0.3s ease;
        }
        
        /* Mobile styles */
        @media (max-width: 1199.98px) {
            body.menu-collapsed .layout-menu {
                transform: translateX(-100%);
            }
            
            .layout-menu-toggle-btn {
                display: flex !important;
            }
        }
        
        /* Animation for toggle button */
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }
        
        .layout-menu-toggle-btn:active i {
            animation: pulse 0.3s ease;
        }
    </style>
</head>
<body>
    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <!-- Menu -->
            @include('partials.sidebar')
            <!-- / Menu -->

            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar - Modified to include hamburger menu -->
                <nav class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme" id="layout-navbar">
                    <div class="d-flex align-items-center">
                        <!-- Hamburger Menu Toggle Button -->
                        <div class="layout-menu-toggle-btn d-xl-none me-3" id="menuToggle">
                            <i class="bx bx-menu"></i>
                        </div>
                        
                        <!-- For desktop, also add toggle (optional) -->
                        <div class="layout-menu-toggle-btn d-none d-xl-block me-3" id="menuToggleDesktop">
                            <i class="bx bx-menu-alt-left"></i>
                        </div>
                    </div>
                    
                    <!-- Rest of your navbar content -->
                    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
                        <!-- Add your existing navbar content here -->
                        <ul class="navbar-nav flex-row align-items-center ms-auto">
                            <!-- User dropdown -->
                            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                                    <div class="avatar avatar-online">
                                        <span class="avatar-initial rounded-circle bg-primary">{{ substr(auth()->user()->name, 0, 1) }}</span>
                                    </div>
                                </a>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="#">
                                            <div class="d-flex">
                                                <div class="flex-shrink-0 me-3">
                                                    <div class="avatar avatar-online">
                                                        <span class="avatar-initial rounded-circle bg-primary">{{ substr(auth()->user()->name, 0, 1) }}</span>
                                                    </div>
                                                </div>
                                                <div class="flex-grow-1">
                                                    <span class="fw-semibold d-block">{{ auth()->user()->name }}</span>
                                                    <small class="text-muted">{{ auth()->user()->role }}</small>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                                    <li>
                                        <div class="dropdown-divider"></div>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                            <i class="bx bx-power-off me-2"></i>
                                            <span class="align-middle">Log Out</span>
                                        </a>
                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                            @csrf
                                        </form>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!-- / Navbar -->

                <!-- Content wrapper -->
                <div class="content-wrapper">
                    <!-- Content -->
                    <div class="container-fluid flex-grow-1 container-p-y">
                        @yield('content')
                    </div>
                    <!-- / Content -->

                    <!-- Footer -->
                    @include('partials.footer')
                    <!-- / Footer -->
                    
                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>
    </div>
    <!-- / Layout wrapper -->

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="{{ asset('sneat/assets/vendor/libs/jquery/jquery.js') }}"></script>
    <script src="{{ asset('sneat/assets/vendor/libs/popper/popper.js') }}"></script>
    <script src="{{ asset('sneat/assets/vendor/js/bootstrap.js') }}"></script>
    <script src="{{ asset('sneat/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js') }}"></script>
    <script src="{{ asset('sneat/assets/vendor/js/menu.js') }}"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->
    @stack('scripts')
    
    <!-- Main JS -->
    <script src="{{ asset('sneat/assets/js/main.js') }}"></script>
    
    <!-- Page JS -->
    @yield('page-js')
    
    <!-- Sidebar Toggle Script -->
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const menuToggle = document.getElementById('menuToggle');
        const menuToggleDesktop = document.getElementById('menuToggleDesktop');
        const layoutMenu = document.querySelector('.layout-menu');
        const layoutPage = document.querySelector('.layout-page');
        const overlay = document.querySelector('.layout-overlay');
        
        // Check if sidebar state is saved in localStorage
        const sidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
        
        // Apply saved state on page load
        if (sidebarCollapsed) {
            document.body.classList.add('menu-collapsed');
        }
        
        // Toggle menu function
        function toggleMenu() {
            document.body.classList.toggle('menu-collapsed');
            
            // Save state to localStorage
            const isCollapsed = document.body.classList.contains('menu-collapsed');
            localStorage.setItem('sidebarCollapsed', isCollapsed);
            
            // Update icons
            updateToggleIcons(isCollapsed);
            
            // Trigger resize event for any components that need to adjust
            window.dispatchEvent(new Event('resize'));
        }
        
        // Update toggle icons based on state
        function updateToggleIcons(isCollapsed) {
            // Update mobile toggle
            if (menuToggle) {
                const icon = menuToggle.querySelector('i');
                if (icon) {
                    if (isCollapsed) {
                        icon.classList.remove('bx-menu');
                        icon.classList.add('bx-menu-alt-right');
                    } else {
                        icon.classList.remove('bx-menu-alt-right');
                        icon.classList.add('bx-menu');
                    }
                }
            }
            
            // Update desktop toggle
            if (menuToggleDesktop) {
                const icon = menuToggleDesktop.querySelector('i');
                if (icon) {
                    if (isCollapsed) {
                        icon.classList.remove('bx-menu-alt-left');
                        icon.classList.add('bx-menu-alt-right');
                    } else {
                        icon.classList.remove('bx-menu-alt-right');
                        icon.classList.add('bx-menu-alt-left');
                    }
                }
            }
        }
        
        // Add click event to mobile toggle
        if (menuToggle) {
            menuToggle.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                toggleMenu();
            });
        }
        
        // Add click event to desktop toggle
        if (menuToggleDesktop) {
            menuToggleDesktop.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                toggleMenu();
            });
        }
        
        // Handle overlay click (for mobile)
        if (overlay) {
            overlay.addEventListener('click', function() {
                if (window.innerWidth < 1200) {
                    toggleMenu();
                }
            });
        }
        
        // Handle responsive behavior
        function handleResize() {
            if (window.innerWidth >= 1200) {
                // On desktop, we can show/hide based on saved preference
                const isCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
                if (isCollapsed) {
                    document.body.classList.add('menu-collapsed');
                } else {
                    document.body.classList.remove('menu-collapsed');
                }
            } else {
                // On mobile, start collapsed
                document.body.classList.add('menu-collapsed');
                localStorage.setItem('sidebarCollapsed', 'true');
            }
            
            // Update icons
            const isCollapsed = document.body.classList.contains('menu-collapsed');
            updateToggleIcons(isCollapsed);
        }
        
        // Add resize listener
        window.addEventListener('resize', handleResize);
        
        // Initial call to set correct state
        handleResize();
        
        // Initialize icons
        updateToggleIcons(document.body.classList.contains('menu-collapsed'));
    });
    </script>
    
    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
    
    <!-- Your existing styles -->
    <style>
    /* Custom staff position colors */
    .badge-field-executive {
        background-color: #007BFF;
        color: white;
    }

    .badge-sales-manager {
        background-color: #28A745;
        color: white;
    }

    .badge-field-worker {
        background-color: #FFC107;
        color: white;
    }

    .badge-admin {
        background-color: #6F42C1;
        color: white;
    }

    .badge-other {
        background-color: #6c757d;
        color: white;
    }
    
    /* Clean table styling */
    .table {
        border-collapse: collapse;
    }

    .table th,
    .table td {
        padding: 0.75rem;
        vertical-align: top;
        border-top: 1px solid #dee2e6;
    }

    .table thead th {
        background-color: #f8f9fa;
        border-bottom: 2px solid #dee2e6;
        font-weight: 600;
    }

    .table-hover tbody tr:hover {
        background-color: rgba(0, 0, 0, 0.02);
    }

    /* Action button styling */
    .btn-group .btn {
        padding: 0.25rem 0.5rem;
        font-size: 0.875rem;
        line-height: 1;
    }

    .btn-outline-warning {
        color: #ffc107;
        border-color: #ffc107;
    }

    .btn-outline-warning:hover {
        background-color: #ffc107;
        color: #fff;
    }

    .btn-outline-info {
        color: #17a2b8;
        border-color: #17a2b8;
    }

    .btn-outline-info:hover {
        background-color: #17a2b8;
        color: #fff;
    }

    .btn-outline-danger {
        color: #dc3545;
        border-color: #dc3545;
    }

    .btn-outline-danger:hover {
        background-color: #dc3545;
        color: #fff;
    }

    /* Sort arrows */
    .bx-up-arrow-alt,
    .bx-down-arrow-alt {
        font-size: 0.8rem;
    }

    .bx-up-arrow-alt:hover,
    .bx-down-arrow-alt:hover {
        color: #007bff;
    }
    </style>

  <!-- Add this before closing </body> tag -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    const sidebarToggle = document.getElementById('sidebarMenuToggle');
    const layoutMenu = document.querySelector('.layout-menu');
    const layoutPage = document.querySelector('.layout-page');
    const overlay = document.querySelector('.layout-overlay');
    
    // Check if sidebar state is saved in localStorage
    const sidebarHidden = localStorage.getItem('sidebarHidden') === 'true';
    
    // Apply saved state on page load
    if (sidebarHidden) {
        document.body.classList.add('sidebar-hidden');
    }
    
    // Toggle sidebar function
    function toggleSidebar() {
        document.body.classList.toggle('sidebar-hidden');
        
        // Save state to localStorage
        const isHidden = document.body.classList.contains('sidebar-hidden');
        localStorage.setItem('sidebarHidden', isHidden);
        
        // Update icon
        const icon = sidebarToggle.querySelector('i');
        if (icon) {
            if (isHidden) {
                icon.classList.remove('bx-menu');
                icon.classList.add('bx-chevron-right');
            } else {
                icon.classList.remove('bx-chevron-right');
                icon.classList.add('bx-menu');
            }
        }
        
        // Trigger resize event for any components that need to adjust
        window.dispatchEvent(new Event('resize'));
    }
    
    // Add click event to toggle button
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            toggleSidebar();
        });
    }
    
    // Handle overlay click (for mobile)
    if (overlay) {
        overlay.addEventListener('click', function() {
            if (window.innerWidth < 1200) {
                toggleSidebar();
            }
        });
    }
    
    // Handle responsive behavior
    function handleResize() {
        if (window.innerWidth >= 1200) {
            // On desktop, respect saved preference
            const isHidden = localStorage.getItem('sidebarHidden') === 'true';
            if (isHidden) {
                document.body.classList.add('sidebar-hidden');
            } else {
                document.body.classList.remove('sidebar-hidden');
            }
        } else {
            // On mobile, auto-hide sidebar
            document.body.classList.add('sidebar-hidden');
            localStorage.setItem('sidebarHidden', 'true');
        }
        
        // Update icon
        const icon = sidebarToggle.querySelector('i');
        if (icon) {
            if (document.body.classList.contains('sidebar-hidden')) {
                icon.classList.remove('bx-menu');
                icon.classList.add('bx-chevron-right');
            } else {
                icon.classList.remove('bx-chevron-right');
                icon.classList.add('bx-menu');
            }
        }
    }
    
    // Add resize listener
    window.addEventListener('resize', handleResize);
    
    // Initial call to set correct state
    handleResize();
});
</script>

<style>
/* Sidebar hidden state - makes content full width */
body.sidebar-hidden .layout-menu {
    transform: translateX(-100%);
    transition: transform 0.3s ease;
}

body.sidebar-hidden .layout-page {
    margin-left: 0 !important;
    width: 100% !important;
    transition: margin-left 0.3s ease, width 0.3s ease;
}

/* Ensure smooth transitions */
.layout-menu,
.layout-page {
    transition: transform 0.3s ease, margin-left 0.3s ease, width 0.3s ease;
}

/* Hamburger icon styling inside sidebar */
#sidebarMenuToggle {
    cursor: pointer;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 40px;
    height: 40px;
    border-radius: 50%;
}

#sidebarMenuToggle:hover {
    background-color: rgba(105, 108, 255, 0.1);
}

#sidebarMenuToggle i {
    font-size: 1.5rem;
    color: #697a8d;
}

#sidebarMenuToggle:hover i {
    color: #696cff;
}

/* For mobile devices */
@media (max-width: 1199.98px) {
    .layout-menu-toggle {
        display: flex !important;
    }
    
    body.sidebar-hidden .layout-menu {
        transform: translateX(-100%);
    }
    
    /* Ensure content takes full width on mobile when sidebar hidden */
    body.sidebar-hidden .layout-page {
        margin-left: 0 !important;
        width: 100% !important;
    }
}

/* Animation for toggle button */
@keyframes pulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.1); }
    100% { transform: scale(1); }
}

#sidebarMenuToggle:active i {
    animation: pulse 0.3s ease;
}
</style>
</body>
</html>