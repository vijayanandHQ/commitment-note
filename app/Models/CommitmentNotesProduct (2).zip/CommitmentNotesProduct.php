<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CommitmentNotesProduct extends Model
{
    use HasFactory;

    protected $table = 'commitment_notes_product';
    protected $primaryKey = 'id'; // FIXED: lowercase to match DB column

    protected $fillable = [
        'commitment_notes_id',
        'product_name',
        'quantity',
        'mrp',
        'total_price',
        'supplier_id',
        'order_qty',
        'remarks',
    ];

    protected $casts = [
        'quantity'   => 'integer',
        'order_qty'  => 'integer',
        'supplier_id'=> 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Get the commitment note that owns the product.
     */
    public function commitmentNote()
    {
        return $this->belongsTo(CommitmentNote::class, 'commitment_notes_id');
    }

    /**
     * ADDED: Get the supplier for this product.
     */
    public function supplier()
    {
        return $this->belongsTo(Supplier::class, 'supplier_id');
    }
}