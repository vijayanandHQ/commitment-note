<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CommitmentNotesProduct extends Model
{
    use HasFactory;

    protected $table = 'commitment_notes_product';

    protected $fillable = [
        'commitment_notes_id',
        'product_name',
        'quantity',
        'mrp',
        'total_price'
    ];

    protected $casts = [
        'quantity' => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    /**
     * Get the commitment note that owns the product.
     */
    public function commitmentNote()
    {
        return $this->belongsTo(CommitmentNote::class, 'commitment_notes_id');
    }
}